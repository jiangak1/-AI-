import os

def list_python_files(project_path):
    py_files = []
    for root, dirs, files in os.walk(project_path):
        for file in files:
            if file.endswith(".py"):
                py_files.append(os.path.join(root, file))
    return py_files

def analyze_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    func_count = content.count('def ')
    class_count = content.count('class ')
    return {'file': file_path, 'functions': func_count, 'classes': class_count}

def analyze_project(project_path):
    files = list_python_files(project_path)
    report = []
    for f in files:
        report.append(analyze_file(f))
    return report
