from utils import run_command
from config import DEPLOY_SCRIPT

def deploy_project():
    print("部署项目...")
    result = run_command(f"bash {DEPLOY_SCRIPT}")
    print(result)
