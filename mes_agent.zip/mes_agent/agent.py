from config import MES_PROJECT_PATH, GIT_REPO_URL
from code_analyzer import analyze_project
from refactor_engine import refactor_project
from test_generator import generate_unit_test
from deploy_manager import deploy_project
from utils import run_command
import os

def main():
    print("=== MES 自动化 MVP Agent ===")
    if not os.path.exists(MES_PROJECT_PATH):
        print("克隆代码库...")
        run_command(f"git clone {GIT_REPO_URL} {MES_PROJECT_PATH}")
    else:
        print("更新代码库...")
        run_command(f"git -C {MES_PROJECT_PATH} pull")
    report = analyze_project(MES_PROJECT_PATH)
    for r in report:
        print(r)
    files = [r['file'] for r in report]
    print("自动重构代码...")
    refactor_results = refactor_project(files)
    for res in refactor_results:
        print(res)
    print("生成单元测试...")
    for f in files:
        test_file = generate_unit_test(f)
        print(f"生成测试: {test_file}")
    deploy_project()
    print("=== 自动化任务完成 ===")

if __name__ == '__main__':
    main()
