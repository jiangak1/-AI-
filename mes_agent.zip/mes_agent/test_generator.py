import os

def generate_unit_test(file_path):
    base_name = os.path.basename(file_path).replace('.py','')
    test_file = f'tests/test_{base_name}.py'
    content = f"""import unittest
from {base_name} import *

class Test{base_name.capitalize()}(unittest.TestCase):
    def test_placeholder(self):
        self.assertTrue(True)

if __name__ == '__main__':
    unittest.main()
"""
    os.makedirs('tests', exist_ok=True)
    with open(test_file, 'w', encoding='utf-8') as f:
        f.write(content)
    return test_file
