# MES 自动化 MVP Agent

可运行的 MES 自动化重构与部署 MVP。

## 使用

1. 安装依赖：
2. 运行：
