#!/bin/bash
echo "部署成功！"
