MES_PROJECT_PATH = "./mes_project"
GIT_REPO_URL = "https://github.com/your-org/mes-project.git"
DEPLOY_SCRIPT = "./deploy.sh"
LOG_FILE = "logs/agent.log"
