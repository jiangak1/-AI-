import subprocess
import logging
from config import LOG_FILE

logging.basicConfig(filename=LOG_FILE, level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

def run_command(cmd):
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        logging.info(f"Executed: {cmd}\nOutput: {result.stdout}")
        if result.stderr:
            logging.error(result.stderr)
        return result.stdout
    except Exception as e:
        logging.error(f"Command failed: {cmd}, Error: {str(e)}")
        return None
