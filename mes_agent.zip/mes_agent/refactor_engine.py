import subprocess

def refactor_file(file_path):
    subprocess.run(f"black {file_path}", shell=True)
    subprocess.run(f"isort {file_path}", shell=True)
    return f"{file_path} refactored"

def refactor_project(files):
    results = []
    for f in files:
        results.append(refactor_file(f))
    return results
